
class Basket:

    def __init__(self, name, quantity, price):
        self.name = name
        self.qty = quantity
        self.price = price

    def get_name(self):
        return self.name

    def get_total_price(self):
        total = self.price*self.qty
        return total

item = Basket('shoe', 5, 5000)
total = item.get_total_price()
print(total)